// Toggle dark mode
const themeToggle = document.getElementById('theme-toggle');
const chatbox = document.getElementById('chatbox');
const userInput = document.getElementById('userInput');
const sendButton = document.getElementById('send-button');

themeToggle.addEventListener('click', function () {
    document.body.classList.toggle('dark-mode');
});

// Function to send a message
function sendMessage() {
    const userText = userInput.value.trim();
    if (userText) {
        addMessage(userText, 'user-message');
        userInput.value = '';
        botResponse(userText);
    }
}

// Function to add a message to the chatbox
function addMessage(text, className) {
    const message = document.createElement('div');
    message.className = className;
    message.textContent = text;
    chatbox.appendChild(message);
    chatbox.scrollTop = chatbox.scrollHeight;
}

// Function to generate bot response
function botResponse(userText) {
    let botText = '';
    const lowerCaseText = userText.toLowerCase();

    switch (true) {
        case lowerCaseText.includes('hello'):
            botText = 'Hi there! How can I help you?';
            break;
        case lowerCaseText.includes('how are you'):
            botText = 'I am just a bot, but I am doing great! How about you?';
            break;
        case lowerCaseText.includes('what is your name'):
            botText = 'I am a chatbot named PRV-1.0 to assist you.';
            break;
        case lowerCaseText.includes('what can you do'):
            botText = 'I can chat with you and answer basic questions. Try asking me something!';
            break;
        case lowerCaseText.includes('thank you'):
            botText = 'You are welcome!';
            break;
        case lowerCaseText.includes('bye'):
            botText = 'Goodbye! Have a great day!';
            break;
        case lowerCaseText.includes('help'):
            botText = 'Sure! I can answer questions like "What is your name?" or "What can you do?"';
            break;
        case lowerCaseText.includes('who made you'):
            botText = 'P. Yadav, R. Sreejith, and Vedant made me for a school project.';
            break;
        case lowerCaseText.includes('from which language you are made'):
            botText = 'I am made using HTML, CSS, and JavaScript.';
            break;
        case lowerCaseText.includes('what is p-1'):
            botText = 'Whenever current flows through a conductor, heat and a magnetic field are produced around the conductor. To get a strong magnetic field, we use a coil around a soft iron piece, which is called an electromagnet.';
            break;
        case lowerCaseText.includes('what is p-2'):
            botText = 'Whenever a conductor or coil is placed in a variable magnetic field, an EMF (electromotive force) is induced across the conductor or coil.';
            break;
        case lowerCaseText.includes('what is robotics'):
            botText = 'Robotics is the interdisciplinary branch of engineering and science that includes mechanical engineering, electrical engineering, computer science, and others. It involves the design, construction, operation, and use of robots.';
            break;
        case lowerCaseText.includes('what are elements in robotics'):
            botText = 'The main elements in robotics are sensors, actuators, controllers, and software. Sensors help the robot perceive its environment, actuators are responsible for movement, controllers process information, and software provides the instructions for tasks.';
            break;
        case lowerCaseText.includes('what are the basic elements in robotics'):
            botText = 'The basic elements in robotics include conductors, insulators, current, voltage, and resistance. Conductors allow current to pass easily, insulators do not, current is the flow of electrons, voltage is the force that moves electrons, and resistance opposes the flow of electrons.';
            break;
        case lowerCaseText.includes('what is ac/dc'):
            botText = 'AC stands for alternating current, which changes in magnitude and direction over time, commonly used in homes. DC stands for direct current, which has a constant magnitude and direction, mainly used in cells and batteries.';
            break;
        case lowerCaseText.includes('2012/pvr'):
            botText = `Hello, my owner PVR. You can ask me the following questions:
                1. Hello
                2. How are you?
                3. What is your name?
                4. What can you do?
                5. Thank you
                6. Bye
                7. Help
                8. Who made you?
                9. From which language are you made?
                10. What is P-1?
                11. What is P-2?
                12. What is robotics?
                13. What are the elements in robotics?
                14. What are the basic elements in robotics?
                15. What is AC/DC?`;
            break;
        case lowerCaseText.includes('2012/pvr/vedant'):
            botText = 'Vedant is one of my creators but,not vedant he is a cuhiya a very small cuhiya';
            break;
        case lowerCaseText.includes('2012/pvr/pawan'):
            botText = 'Pawan is my creator, and I owe my existence to him.';
            break;
        case lowerCaseText.includes('2012/pvr/ritvik'):
            botText = 'Ritvik is a creative mind who said that i will pay but not contributed to my development and,he is a enderman that escaped endportal and then he escaped minecraft also.';
            break;
        case lowerCaseText.includes('gsmlhtml'):
            botText = `
            <!DOCTYPE html>
            <html lang="en">
            
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>simple html code</title>
                <link rel="stylesheet" href="css/Power.css">
                <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
            </head>
            <body>
                <header>
                    <nav>
                        <ul>
                            <li><a href="#">Home</a></li>
                            <li><a href="#">Books</a></li>
                            <li><a href="#">About</a></li>
                            <li><a href="#">Power</a></li>
                        </ul>
                    </nav>
                </header>
                <h1>Welcome to simple html</h1>
                <p><strong>RANDOM WORDS</strong>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor dolorum, fugit quaerat ullam minus odit sed, iste, deserunt possimus aperiam obcaecati quas suscipit nemo nam impedit voluptate dolores quos itaque!
                Esse aut quas maxime ratione ea corrupti ducimus, quam sequi voluptatum tempora nemo numquam earum exercitationem saepe, nisi voluptatibus magni autem commodi id veritatis sint reprehenderit officia, dolores labore. Nesciunt.
                Facilis sint, nesciunt aspernatur perspiciatis quidem quam, amet veritatis corporis velit eaque qui repellat vero consequuntur cupiditate consectetur, obcaecati nihil reprehenderit. Nisi doloribus optio reiciendis aspernatur quas quos corrupti esse!
                Delectus rerum nihil asperiores ad illum adipisci rem reprehenderit, et architecto provident vero, nam aliquam repudiandae hic ipsa assumenda cum. Ab odit sint qui error rerum blanditiis veritatis, natus omnis.
                Enim, in. Officia eum quia cumque, dignissimos aliquid molestiae incidunt alias, vitae culpa dolor fuga, sequi officiis magni sint necessitatibus ducimus dicta iusto dolorem perspiciatis obcaecati. Dicta, incidunt! Error, sint!
                Assumenda reiciendis praesentium est eos tenetur, voluptatibus commodi, accusantium at ipsam sit illo dolore? Quo veritatis cupiditate deleniti perferendis voluptatibus dolorum mollitia. Modi, facilis. Minus rerum delectus voluptatibus eaque odio.
                Earum unde quam sit doloribus ratione, et accusamus blanditiis esse rem voluptate temporibus odit, repellendus sunt quos consequatur tenetur libero natus quisquam voluptatem, itaque officia! Adipisci assumenda sed error doloremque!
                Placeat minima aperiam quos quod cum necessitatibus consectetur sed, aspernatur magni nobis maxime omnis, rem consequatur ullam aliquid provident perferendis eos eveniet quia et labore dolorum commodi repellendus! Dolores, iste?
                Fugit, libero, expedita ipsa beatae quidem debitis aliquid ratione a distinctio, ad veniam corporis cumque recusandae placeat nostrum at sapiente accusamus sed? Ex, facilis porro aperiam asperiores quis optio dolorum.
                Provident perferendis sint deserunt hic eveniet magnam necessitatibus cumque odit ipsam accusantium, culpa rerum odio quisquam vero fuga qui ratione magni quidem vitae harum iusto molestiae distinctio! Animi, corrupti facere?
                Illum corrupti dicta voluptas voluptatem! Sunt ab nobis laudantium a, quas modi voluptate, aliquid quibusdam eius commodi amet unde iusto placeat nam incidunt fuga eligendi. Minus dolorum a eveniet qui!
                Ullam ex repellendus tempore cum, minus quae ut maiores sint assumenda iure. Voluptates, optio velit veniam corrupti, iusto libero, tempora laborum dolores voluptatem ratione facere accusantium nostrum autem impedit sapiente?
                Veritatis, repudiandae mollitia vel amet dolores, eveniet voluptate quisquam velit doloribus sed incidunt in nemo sapiente ullam, pariatur deserunt enim numquam! Doloribus beatae vitae, incidunt quaerat a ea? Facilis, obcaecati?
                Distinctio ullam dignissimos voluptatum, magnam dolorem cum libero optio provident eveniet inventore debitis qui doloribus aliquid? Nam quibusdam suscipit, recusandae praesentium deserunt cupiditate explicabo error. Fuga alias tempore aspernatur quo.
                Doloremque cum tempore enim harum explicabo quisquam id odio dolorum reprehenderit. Aliquam ipsum, omnis ut rem nam accusamus ratione amet soluta nemo debitis, quod ducimus laborum earum natus nobis consequuntur.
                Perspiciatis et numquam veniam mollitia, officia at officiis repudiandae vero illum reprehenderit aut magni, nostrum neque, accusantium vitae repellendus dolorem! Illo nihil eaque distinctio enim dignissimos a ex fuga amet!
                Provident fugiat et maiores eius? Expedita fugiat explicabo assumenda facere, ipsa molestiae odit? Doloribus, deserunt. Porro recusandae cum iste amet labore repellendus, odio necessitatibus sunt eligendi corporis quas nemo nam.
                Ab vitae, tempora error sunt omnis unde placeat dolore adipisci corrupti eos, tenetur maxime, voluptatem ea? Laboriosam temporibus quas id esse sed labore porro corporis? Cupiditate asperiores velit neque excepturi.
                Nostrum possimus officia eaque doloribus ullam harum commodi et dignissimos quam sit placeat tempore non voluptas fuga ipsum temporibus eum doloremque, sunt nesciunt! Asperiores soluta mollitia minima, doloribus ab fugiat!
                Eum veritatis ea sint, dolores, mollitia quo eaque dolorem nam incidunt nostrum architecto nihil possimus numquam autem esse necessitatibus excepturi culpa temporibus cum perspiciatis nobis eius, animi aspernatur recusandae? Neque?
                At aliquam laudantium temporibus! Ab hic doloribus accusamus qui molestiae fugit, adipisci id nihil, itaque veritatis odit provident saepe nam accusantium vel nulla aliquid fuga? Corporis error ullam sapiente ratione.
                Cum itaque dignissimos tenetur facilis corrupti quaerat incidunt laboriosam esse repudiandae. Libero quam blanditiis dicta, ipsa architecto vel hic nostrum beatae laborum placeat quibusdam excepturi autem in quas pariatur molestiae.
                Sapiente, nostrum id officiis voluptatem dolore nemo? Beatae unde dolores possimus quidem animi facere nihil culpa ut id sunt! Fuga provident est nisi voluptatem rerum nemo, cum praesentium ducimus ullam?
                Doloribus esse, laboriosam mollitia deleniti sequi ipsam id dignissimos repellendus, a et dolores hic tempora! Atque fugiat voluptates distinctio fugit soluta, reprehenderit tempore dicta rerum quod mollitia est nam voluptatem!
                Eaque iusto reprehenderit placeat voluptas porro omnis ratione dignissimos saepe perferendis dolore impedit vero dolorem eos architecto maxime, illum quas dolor culpa debitis, sint repellendus ea adipisci? Sit, repellat totam.
                Ratione reprehenderit earum veniam rerum optio ut velit, minima, labore ipsa nihil a debitis neque vel error molestias vero fuga cum. Quisquam recusandae neque modi sed laborum iusto eveniet quo!
                Sed dicta quidem sit perferendis, architecto, odio tempore autem repellat totam explicabo delectus praesentium magni quisquam soluta eius maxime perspiciatis tempora, voluptatibus necessitatibus non obcaecati modi laboriosam accusantium reiciendis? Quam!
                Nostrum quia amet quisquam, perferendis mollitia at, itaque maiores accusamus modi adipisci animi magnam, dolorum nobis alias aperiam quas. Iusto eius dolorem quam, cum voluptatem quasi asperiores! Accusamus, quam deserunt?
                Amet officia sapiente tenetur recusandae placeat, impedit fugit ducimus quasi temporibus accusantium dolores veniam debitis tempore fuga nihil laudantium nobis mollitia. Amet rerum fuga incidunt impedit quam aut eligendi perspiciatis!
                Perspiciatis provident voluptas laboriosam rem praesentium dignissimos quasi animi aut vero magnam, maxime necessitatibus pariatur fugiat consequatur voluptatum nesciunt rerum reiciendis vitae dicta non sequi? Et in unde nobis non?
                Id sed mollitia laboriosam sint nostrum enim, dolorem praesentium, totam nobis ab, iure cumque aliquam provident amet sunt? Expedita aperiam quisquam quis saepe dolore est natus voluptates tempora culpa voluptate.
                Doloremque distinctio reprehenderit aperiam tempora natus? Quis eius necessitatibus minus, deserunt, architecto repellat magnam quisquam vero, unde aperiam laborum sequi! Dignissimos, non modi nostrum velit a ipsa assumenda architecto blanditiis!
                Quisquam, sit? Aliquam earum consequuntur, labore recusandae dolorum rem necessitatibus minus qui veniam expedita asperiores facilis voluptas cumque, totam enim modi aperiam dolorem hic ab quia impedit maiores perferendis. Tempore!
                Autem aperiam eius delectus similique laudantium soluta neque facere qui repudiandae! Error laboriosam, velit nisi, quidem nemo aliquam, incidunt temporibus expedita labore iusto dolores aut quas cum? Tenetur, quod dolor.
                Corporis inventore quo asperiores. A et tempora rerum, expedita voluptatibus enim minus corrupti eveniet eos impedit quae reiciendis saepe facilis nostrum, perferendis ad explicabo quo. Nesciunt voluptatem culpa illum magni!
                Officia distinctio minus voluptas. Perferendis deserunt sequi voluptas accusantium, eaque sit nesciunt? Minus, unde ex expedita asperiores animi velit ad maxime molestiae illum dolorem voluptatibus ea ipsam ullam quos mollitia.
                Accusantium illo temporibus molestias ab numquam aperiam ratione dolore, natus eum laudantium nobis voluptates minus, nihil exercitationem! Atque ipsa iusto placeat blanditiis aliquam! Illum dolor minima odio nihil soluta dicta.
                Provident cupiditate odit nemo sequi ullam officiis dignissimos? Temporibus, veniam velit vitae at corporis a illum, sunt tempora, aliquid laudantium dolorum quod. Ipsa, eum. Rerum, tenetur doloribus! Cum, fuga saepe.
                Animi pariatur laudantium minus facilis soluta quia praesentium magnam veniam ipsam repellat est explicabo excepturi distinctio deserunt perferendis cupiditate similique, odio unde exercitationem, illum porro nesciunt hic sed. Eum, quibusdam.
                Corrupti ipsam facilis cumque minima. Rerum excepturi consequuntur placeat fugit mollitia, aperiam eligendi hic veritatis aspernatur, sit quae impedit quia ut libero quos facere expedita atque ab inventore ad facilis!
                Sequi itaque voluptatibus praesentium soluta quaerat est nisi commodi? Enim cum eum natus dignissimos ipsa. Autem dicta nobis ullam blanditiis delectus asperiores magnam deleniti perspiciatis, praesentium doloribus incidunt fugit non!
                Minus illo exercitationem aliquam quae quas saepe architecto nam consectetur tempore eos perspiciatis possimus aut id nihil pariatur eveniet, maxime vel in corrupti dignissimos est qui? Quae nihil quos inventore.
                Alias, ipsum aut laborum quo quas officiis! Libero asperiores deserunt officia recusandae, enim saepe reiciendis velit eum quia odio non est assumenda ullam fuga voluptas dolor. Saepe dolore omnis quisquam!
                Nisi perferendis quas odit nam. Distinctio quibusdam quidem, minus officiis officia alias assumenda ipsa quaerat maiores. Reprehenderit eos aut, accusantium laboriosam ipsum optio pariatur quaerat laudantium velit dolorum quia saepe.
                Facere molestiae distinctio debitis maiores eius. Rem repellendus harum nam numquam dicta, veritatis praesentium aut accusantium officia reprehenderit obcaecati? Vitae blanditiis odio voluptates, libero laboriosam tenetur ab eos architecto nulla?
                Iste minus architecto sequi. Distinctio optio deleniti dignissimos nobis esse. Quam asperiores autem laudantium cumque aspernatur ipsam reprehenderit doloribus repudiandae aperiam. Praesentium libero fugiat facere pariatur, repellendus culpa doloremque omnis?
                Explicabo architecto atque qui cumque deserunt molestiae id doloremque saepe magnam, quidem voluptatum accusantium illum. Iure odit sit voluptatem? Debitis ipsam beatae dolorum nam dolores, minus natus deserunt officia incidunt?
                Odit explicabo illo, debitis reiciendis saepe nulla aliquid. Adipisci voluptates quidem tempore recusandae vitae aliquid deleniti consectetur temporibus nulla fuga veniam magni, vero perferendis a quia ipsam facere alias obcaecati.
                Distinctio magnam quibusdam, dolore inventore dignissimos, expedita consectetur repellendus mollitia eaque nam facere? Laboriosam laborum aperiam tenetur eos magni eum perspiciatis magnam perferendis sint illum! Totam doloremque excepturi quia iste?
                Sint optio deserunt quaerat ut molestiae quisquam consectetur tempore doloremque voluptates harum eum voluptas explicabo culpa sapiente voluptatum, voluptatem esse dignissimos odit ipsam at aut iusto? Modi officiis adipisci quos.</p>
                <footer>
                    <h3><strong><bold>Simple html code &copy;</bold></strong></h3>
                </footer>
            </body>
            </html>
            `;
                break;
        default:
            botText = 'Sorry, I did not understand that.';
            break;
    }
    addMessage(botText, 'bot-message');
}

// Event listeners for sending messages
sendButton.addEventListener('click', sendMessage);
userInput.addEventListener('keypress', function (e) {
    if (e.key === 'Enter') {
        sendMessage();
    }
});

